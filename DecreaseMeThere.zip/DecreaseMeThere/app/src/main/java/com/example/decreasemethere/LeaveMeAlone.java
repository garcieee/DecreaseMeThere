package com.example.decreasemethere;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class LeaveMeAlone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_me_alone);
    }
}