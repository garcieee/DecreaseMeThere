package com.example.decreasemethere;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class LEav extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leav);
        //Food Variables
        int Chicken = 120;
        int Burger = 100;
        int Sandwitch = 80;
        int Fries = 50;
        int Soda = 50;

        Button buttonPutMeDown = findViewById(
                R.id.button
        );
        buttonPutMeDown.setOnClickListener(view -> {
            Intent PutMeDownIntent = new Intent(
                    getApplicationContext(), PutMeDown.class

            );
        });// Button for Checking Cart

        Button buttonPutMeDown = findViewById(
                R.id.button10
        );
        buttonPutMeDown.setOnClickListener(view -> {
            Intent PutMeDownIntent = new Intent(
                    getApplicationContext(), PutMeDown.class

            );
            startActivity(PutMeDownIntent);
        });// Button for Chicken
  }
}
