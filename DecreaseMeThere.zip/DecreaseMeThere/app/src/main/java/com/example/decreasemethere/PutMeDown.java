package com.example.decreasemethere;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class PutMeDown extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_put_me_down);

        Button buttonLeaveMeAlone = findViewById(
                R.id.button11
        );
        buttonLeaveMeAlone.setOnClickListener(view -> {
            Intent LeaveMeAloneIntent = new Intent(
                    getApplicationContext(), LeaveMeAlone.class

            );
            startActivity(LeaveMeAloneIntent);
        });
    }
}